﻿//using Microsoft.AspNetCore.Mvc;
//using KütüphaneYönetimSistemi.Models;
//using KütüphaneYönetimSistemi.ViewModels;
//using Microsoft.AspNetCore.DataProtection;

//public class AuthController : Controller
//{




//    private static List<User> users = new List<User>
//    {
//        new User
//        {
//            Id = 1,
//            FullName = "Örnek Kullanıcı",
//            Email = "ornek@example.com",
//            Password = "1234",
//            PhoneNumber = "555-555-5555",
//            JoinDate = DateTime.Now
//        }
//    };
//    [HttpGet]
//    // Kayıt işlemini yönetir.



//    public IActionResult SignUp()
//    {

//        return View();
//    }


//    [HttpPost]
//    public async Task<IActionResult> SignUp(SignUpViewModel model)
//    {
//        if (ModelState.IsValid)
//        {
//            // HttpContext'ten kullanıcı IP'sini alabilirsiniz.
//            var userIp = HttpContext.Connection.RemoteIpAddress.ToString();

//            // Veritabanı veya iş mantığı işlemleri yapılabilir.
//            // await SomeAsyncOperation(model).ConfigureAwait(false);

//            // Başarılı bir işlem sonrası yönlendirme.
//            return RedirectToAction("SignUpSuccess");
//        }

//        // Model doğrulama başarısız ise formu tekrar göster.
//        return View(model);
//    }

//    public IActionResult SignUpSuccess()
//    {
//        return View();
//    }

//    // Giriş işlemini yönetir.
//    public IActionResult Login()
//    {
//        return View();
//    }

//    [HttpPost]
//    public IActionResult Login(string email, string password)
//    {
//        // Kullanıcı girişi doğrulama
//        // Örnek: var user = db.Users.FirstOrDefault(u => u.Email == email && u.Password == password);
//        return RedirectToAction("Index", "Home"); // Giriş başarılı ise yönlendir
//    }
//}
using Microsoft.AspNetCore.Mvc;
using KütüphaneYönetimSistemi.Models;
using KütüphaneYönetimSistemi.ViewModels;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KütüphaneYönetimSistemi.Controllers
{
    public class AuthController : Controller
    {
        // Kullanıcı verilerini tutmak için statik liste.
        private static List<User> users = new List<User>
        {
            new User
            {
                Id = 1,
                FullName = "Örnek Kullanıcı",
                Email = "ornek@example.com",
                Password = "1234", // Örnek, parolaların hashlenmiş olması gereklidir.
                PhoneNumber = "555-555-5555",
                JoinDate = DateTime.Now
            }
        };

        // GET: Kayıt sayfasını görüntüleme.
        [HttpGet]
        public IActionResult SignUp()
        {
            return View();
        }

        // POST: Kayıt işlemi.
        [HttpPost]
        public async Task<IActionResult> SignUp(SignUpViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Kullanıcının IP adresini al.
                var userIp = HttpContext.Connection.RemoteIpAddress?.ToString();

                // Yeni kullanıcı oluşturma ve listeye ekleme.
                var newUser = new User
                {
                    Id = users.Count + 1, // Otomatik ID atanabilir.
                    FullName = model.FullName,
                    Email = model.Email,
                    Password = model.Password, // Parola burada hashlenmeli.
                    JoinDate = DateTime.Now
                };

                // Kullanıcıyı listeye ekleme.
                users.Add(newUser);

                // Kayıt başarılı olduğunda, başarı sayfasına yönlendirme.
                return RedirectToAction("SignUpSuccess");
            }

            // Model doğrulama hatalıysa, formu tekrar göster.
            return View(model);
        }

        // Kayıt başarılı olduğunda gösterilecek sayfa.
        public IActionResult SignUpSuccess()
        {
            return View();
        }

        // GET: Giriş sayfasını görüntüleme.
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // POST: Giriş işlemi.
        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            // Kullanıcı doğrulama.
            var user = users.FirstOrDefault(u => u.Email == email && u.Password == password);
            if (user != null)
            {
                // Giriş başarılı ise yönlendirme.
                return RedirectToAction("Index", "Home");
            }

            // Giriş başarısız ise hata mesajı ve formu tekrar gösterme.
            ViewBag.ErrorMessage = "Geçersiz e-posta veya şifre.";
            return View();
        }
    }
}