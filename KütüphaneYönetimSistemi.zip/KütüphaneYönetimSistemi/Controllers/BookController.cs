﻿
//using Microsoft.AspNetCore.Mvc;
//using KütüphaneYönetimSistemi.Models;
//using KütüphaneYönetimSistemi.ViewModels;
//using System.Collections.Generic;
//using System.Linq;

//public class BookController : Controller
//{
//    private static List<BookViewModel> _books = new List<BookViewModel>
//    {
//        // Örnek kitaplar
//        new BookViewModel { Id = 1, Title = "To Kill a Mockingbird", AuthorId = 1, Genre = "Fiction", CopiesAvailable = 5 },
//        // Diğer kitaplar...
//    };

//    public IActionResult List()
//    {
//        var viewModel = _books.Where(x => !x.IsDeleted).ToList();
//        return View(viewModel);
//    }

//    public IActionResult Details(int id)
//    {
//        var book = _books.FirstOrDefault(b => b.Id == id);

//        if (book == null)
//        {
//            return NotFound("Kitap bulunamadı.");
//        }

//        return View(book);
//    }

//    public IActionResult Create()
//    {
//        return View();
//    }

//    [HttpPost]
//    public IActionResult Create(BookViewModel book)
//    {
//        if (ModelState.IsValid)
//        {
//            _books.Add(book);
//            return RedirectToAction("List");
//        }
//        return View(book);
//    }

//    public IActionResult Edit(int id)
//    {
//        var book = _books.FirstOrDefault(b => b.Id == id);
//        if (book == null)
//        {
//            return NotFound("Kitap bulunamadı.");
//        }
//        return View(book);
//    }

//    [HttpPost]
//    public IActionResult Edit(BookViewModel book)
//    {
//        if (ModelState.IsValid)
//        {
//            var existingBook = _books.FirstOrDefault(b => b.Id == book.Id);
//            if (existingBook != null)
//            {
//                existingBook.Title = book.Title;
//                existingBook.AuthorId = book.AuthorId;
//                existingBook.Genre = book.Genre;
//                existingBook.CopiesAvailable = book.CopiesAvailable;
//            }
//            return RedirectToAction("List");
//        }
//        return View(book);
//    }

//    public IActionResult Delete(int id)
//    {
//        var book = _books.FirstOrDefault(b => b.Id == id);
//        if (book == null)
//        {
//            return NotFound("Kitap bulunamadı.");
//        }
//        return View(book);
//    }

//    [HttpPost, ActionName("Delete")]
//    public IActionResult DeleteConfirmed(int id)
//    {
//        var book = _books.FirstOrDefault(b => b.Id == id);
//        if (book != null)
//        {
//            _books.Remove(book);
//        }
//        return RedirectToAction("List");
//    }
//}

using KütüphaneYönetimSistemi.ViewModels;
using Microsoft.AspNetCore.Mvc;

public class BookController : Controller
{
    private static List<BookViewModel> _books = new List<BookViewModel>
    {
        new BookViewModel { Id = 1, Title = "To Kill a Mockingbird", AuthorId = 1, Genre = "Fiction", CopiesAvailable = 5 },
        // Diğer kitaplar...
    };

    public IActionResult List()
    {
        var viewModel = _books.Where(x => !x.IsDeleted).ToList();
        return View(viewModel);
    }

    public IActionResult Details(int id)
    {
        var book = _books.FirstOrDefault(b => b.Id == id);

        if (book == null)
        {
            return NotFound("Kitap bulunamadı.");
        }

        return View(book);
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Create(BookViewModel book)
    {
        if (ModelState.IsValid)
        {
            _books.Add(book);
            return RedirectToAction("List");
        }
        return View(book);
    }

    public IActionResult Edit(int id)
    {
        var book = _books.FirstOrDefault(b => b.Id == id);
        if (book == null)
        {
            return NotFound("Kitap bulunamadı.");
        }
        return View(book);
    }

    [HttpPost]
    public IActionResult Edit(BookViewModel book)
    {
        if (ModelState.IsValid)
        {
            var existingBook = _books.FirstOrDefault(b => b.Id == book.Id);
            if (existingBook != null)
            {
                existingBook.Title = book.Title;
                existingBook.AuthorId = book.AuthorId;
                existingBook.Genre = book.Genre;
                existingBook.CopiesAvailable = book.CopiesAvailable;
            }
            return RedirectToAction("List");
        }
        return View(book);
    }

    public IActionResult Delete(int id)
    {
        var book = _books.FirstOrDefault(b => b.Id == id);
        if (book == null)
        {
            return NotFound("Kitap bulunamadı.");
        }
        return View(book);
    }

    [HttpPost, ActionName("Delete")]
    public IActionResult DeleteConfirmed(int id)
    {
        var book = _books.FirstOrDefault(b => b.Id == id);
        if (book != null)
        {
            _books.Remove(book);
        }
        return RedirectToAction("List");
    }
}

