﻿using System.ComponentModel.DataAnnotations;

namespace KütüphaneYönetimSistemi.ViewModels
{
    public class SignUpViewModel
    {
        [Required(ErrorMessage = "Ad ve Soyad gereklidir.")]
        public string FullName { get; set; }

        [Required(ErrorMessage = "Email gereklidir.")]
        [EmailAddress(ErrorMessage = "Geçerli bir email adresi giriniz.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Şifre gereklidir.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Şifre doğrulaması gereklidir.")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Şifreler eşleşmiyor.")]
        public string ConfirmPassword { get; set; }
    }
}
